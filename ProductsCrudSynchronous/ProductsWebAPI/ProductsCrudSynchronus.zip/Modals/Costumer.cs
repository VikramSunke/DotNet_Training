﻿namespace ProductsWebAPI.Modals
{
    public class Costumer
    {
        
        public int Id { get; set; }

        public string CName { get; set; }
        //public int MyProperty { get; set; }
    }
}
