﻿namespace ProductsWebAPI.Modals
{
    public class CostumerProduct
    {
        public int Id { get; set; }
        public int PId { get; set; }
        public int CId { get; set; }


    }
}
