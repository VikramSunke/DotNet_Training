﻿namespace CrudUsingAsyncAwait.Modals
{
    public class Student
    {
        public int Id { get; set; }
        public string SName { get; set; }
        public string SBranch { get; set; }
        public int SAge { get; set; }
    }
}
