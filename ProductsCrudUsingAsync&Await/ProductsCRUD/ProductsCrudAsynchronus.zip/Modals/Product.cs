﻿namespace ProductsCRUD.Modals
{
    public class Product
    {
        public int Id { get; set; }

        public string PName { get; set; }
        public decimal PPrice { get; set; }
    }
}
