﻿namespace ProductsCRUD.Modals
{
    public class CustomerProduct
    {
        public int Id { get; set; }
        public int PId { get; set; }
        public int CId { get; set; }
    }
}
