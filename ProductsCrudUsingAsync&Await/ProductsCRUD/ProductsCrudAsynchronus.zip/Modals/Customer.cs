﻿namespace ProductsCRUD.Modals
{
    public class Customer
    {
        public int Id { get; set; }
        public string CName { get; set; }
    }
}
